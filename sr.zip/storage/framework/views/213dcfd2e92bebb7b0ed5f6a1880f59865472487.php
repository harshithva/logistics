<?php $__env->startComponent('mail::message'); ?>
# Shipment Created<br>
<img src="https://i.ibb.co/HrrpY2C/Logo-Color-Text-Below.jpg" style="width:150px;"><br>
<hr>
Hi, This Message is to inform you that your shipment with Docket number <?php echo e($data['docket_no']); ?> has been successfully
created.<br>

<hr>
Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH D:\coding\laravel\cargo\resources\views/emails/shipment/created.blade.php ENDPATH**/ ?>