<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::apiResource("shipments", 'ShipmentController');
Route::apiResource("shipments/{id}/payments", 'PaymentController');
Route::apiResource("shipments/{id}/status", 'ShipmentStatusController');
Route::apiResource("quotations", 'QuoteController');
Route::post("quotations/{id}/status/approve", 'QuoteController@approve_status');
Route::post("quotations/{id}/status/decline", 'QuoteController@decline_status');

Route::get("shipments/{id}/balance_amount", 'ShipmentController@balance_amount');
Route::get("shipments/{id}/shipment_status", 'ShipmentController@shipment_status');
Route::post("shipments/{id}/shipment_send_email", 'ShipmentController@shipment_send_email');
Route::post("shipments/{id}/shipment_send_sms", 'ShipmentController@shipment_send_sms');

Route::apiResource("customers", 'CustomerController');
