<?php

namespace App\Http\Controllers;

use App\ShipmentInsurance;
use Illuminate\Http\Request;

class ShipmentInsuranceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ShipmentInsurance  $shipmentInsurance
     * @return \Illuminate\Http\Response
     */
    public function show(ShipmentInsurance $shipmentInsurance)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ShipmentInsurance  $shipmentInsurance
     * @return \Illuminate\Http\Response
     */
    public function edit(ShipmentInsurance $shipmentInsurance)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ShipmentInsurance  $shipmentInsurance
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ShipmentInsurance $shipmentInsurance)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ShipmentInsurance  $shipmentInsurance
     * @return \Illuminate\Http\Response
     */
    public function destroy(ShipmentInsurance $shipmentInsurance)
    {
        //
    }
}
