## Logistics Management

This powerful CRM was developed using Vuejs and Laravel API.

### Features

+ SPA
+ Customizable
+ Create Shipment
+ Print Invoice
+ Send quotes
+ Download Reports
+ Customer login
+ Staff Login
+ Send SMS
+ Send Email
+ Receive quotes
+ Send Invoices
+ Beautiful mail templates
