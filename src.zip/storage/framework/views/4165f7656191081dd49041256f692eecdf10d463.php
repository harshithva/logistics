




<?php $__env->startSection('content'); ?>

<?php echo $__env->make('beautymail::templates.widgets.articleStart', [
'heading' => 'Gurukal Logistics',
'level' => 'h1'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<p>Freight Invoice Number: <?php echo e($request->freight_invoice_number); ?></p>
<h5>Feedback</h5>
<p><?php echo e($request->feedback); ?></p>



<?php echo $__env->make('beautymail::templates.widgets.newfeatureEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.ark', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laravel\cargo\resources\views/emails/shipment/feedback.blade.php ENDPATH**/ ?>