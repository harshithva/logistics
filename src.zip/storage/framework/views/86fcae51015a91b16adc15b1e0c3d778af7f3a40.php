




<?php $__env->startSection('content'); ?>

<?php echo $__env->make('beautymail::templates.widgets.articleStart', [
'heading' => 'Gurukal Logistics',
'level' => 'h1'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($status == 'Awaiting Pickup'): ?>
<h4 class="secondary"><strong>Shipment Created</strong></h4>
<br>
<p>Your Consignment is ready for dispatch with docket number <?php echo e($docket); ?>.<br> Login at gurukal.in Or
    track your consignment at Gurukal.co.in <br>Regards Gurukal Logistics.</p>

<?php endif; ?>

<?php if($status == 'Dispatched'): ?>
<h4 class="secondary"><strong>Shipment Dispatched</strong></h4>
<br>
<p>Your Consignment with docket number <?php echo e($docket); ?> is Dispatched.<br> Login at gurukal.in Or track
    your consignment at Gurukal.co.in<br> Regards Gurukal Logistics.</p>
<?php endif; ?>

<?php if($status == 'Delivered'): ?>
<h4 class="secondary"><strong>Shipment Delivered</strong></h4>
<br>
<p>Your Consignment with docket number <?php echo e($docket); ?> is DELIVERED. <br>Kindly let us know how was your
    experience by clicking the following link Gurukal.in/feedback Thank you.<br> Regards Gurukal Logistics.</p>
<?php endif; ?>

<?php if($status == 'Instrasit'): ?>
<h4 class="secondary"><strong>Shipment Intransit</strong></h4>
<br>
<p>Your Consignment with docket number <?php echo e($docket); ?> is Intransit.<br>Regards Gurukal
    Logistics.</p>
<?php endif; ?>


<?php echo $__env->make('beautymail::templates.widgets.newfeatureEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.ark', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laravel\cargo\resources\views\emails\shipment\created.blade.php ENDPATH**/ ?>