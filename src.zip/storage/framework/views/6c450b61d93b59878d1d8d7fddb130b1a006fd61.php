<div class="block">
	<!-- start textbox-with-title -->
	<table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="fulltext">
		<tbody>
		<tr>
			<td>
				<table bgcolor="#ffffff" width="580" cellpadding="0" cellspacing="0" border="0" align="center" class="devicewidth" modulebg="edit">
					<tbody>
					<!-- Spacing -->
					<tr>
						<td width="100%" height="30"></td>
					</tr>
					<!-- Spacing -->
					<tr>
						<td>
							<table width="540" align="center" cellpadding="0" cellspacing="0" border="0" class="devicewidthinner">
								<tbody><?php /**PATH D:\coding\laravel\cargo\vendor\snowfire\beautymail\src\views\templates\minty\contentCenteredStart.blade.php ENDPATH**/ ?>