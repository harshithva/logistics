<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ShipmentStatus;
use Faker\Generator as Faker;

$factory->define(ShipmentStatus::class, function (Faker $faker) {
    return [
        //
    ];
});
