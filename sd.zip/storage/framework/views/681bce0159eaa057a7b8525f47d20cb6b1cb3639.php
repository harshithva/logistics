</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
<!-- end of textbox-with-title -->
</div>
<?php /**PATH D:\coding\laravel\cargo\vendor\snowfire\beautymail\src\views\templates\minty\contentCenteredEnd.blade.php ENDPATH**/ ?>