<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Gurukal- Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="<?php echo e(asset('dashboard/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="<?php echo e(asset('dashboard/css/sb-admin-2.min.css')); ?>" rel="stylesheet">

    <script src="<?php echo e(asset('css/app.css')); ?>"></script>
</head>

<body id="page-top">
    <!-- Page Wrapper -->
    <div id="wrapper">
        <div class="container-fluid">

            <div class="row mt-3 mb-3 ml-3 d-print-none">
                <div class="col-6"></div>
                <div class="col-3"></div>
                <div class="col-3">
                    <a class="btn btn-primary text-white" onclick="javascript:window.print()">
                        <i class="fas fa-print"></i> Print
                    </a>

                </div>
            </div>

            <div class="card" ref="content">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <p>GST No: 29AYGPS3509N2ZQ</p>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col">
                            <img src="https://i.ibb.co/WFdrW4M/Logo-Color-Text-Below.jpg" style="max-width:10rem" />
                        </div>
                        <div class="col"></div>
                        <div class="col">
                            <h5 style="font-size:2rem">
                                <b>FREIGHT INVOICE</b>
                            </h5>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col">
                            <p>
                                GURUKAL LOGISTICS
                                <br />Anchepalya, Bangalore - 560073
                                <br />Mob: +91 9620202001
                                <br />E-mail : logistics@gurukal.co.in
                                <br />Website: www.gurukal.co.in
                                <br />
                            </p>
                        </div>
                        <div class="col"></div>
                        <div class="col">
                            <p style="font-size:1.3rem">
                                <b>Invoice No: <?php echo e($shipment->freight_invoice_number); ?></b>
                            </p>
                            <p>Date of Invoice: <?php echo e($shipment->date); ?></p>

                            <p>Transaction Type</p>
                            <p>
                                <span
                                    class="badge badge-pill badge-success"><?php echo e($shipment->package_transaction_type); ?></span>
                            </p>

                        </div>
                    </div>
                    <hr />

                    <div class="row mt-2">
                        <div class="col">
                            <p>BILL TO</p>

                            <?php if($shipment->bill_to == 'consignor'): ?>
                            <p>
                                <?php echo e($shipment->sender->company_name); ?>

                                <br />
                                <?php echo e($shipment->sender->address); ?>

                            </p>

                            <?php elseif($shipment->bill_to == 'consignee'): ?>
                            <p>
                                <?php echo e($shipment->receiver->company_name); ?>

                                <br />
                                <?php echo e($shipment->receiver->address); ?>

                            </p>

                            <?php else: ?>

                            <p>
                                <?php echo e($shipment->sender->company_name); ?>

                                <br />
                                <?php echo e($shipment->sender->address); ?>

                            </p>
                            <?php endif; ?>




                        </div>

                        <div class="col">
                            Consignor Name:
                            <br />
                            <?php echo e($shipment->sender->company_name); ?>

                            <br />
                            <?php echo e($shipment->sender->address); ?>

                            <br />
                            GST: <?php echo e($shipment->sender->gst); ?>

                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col"></div>
                        <div class="col">
                            <p>
                                Consignee Name:
                                <br />
                                <?php echo e($shipment->receiver->company_name); ?>

                                <br />
                                <?php echo e($shipment->receiver->address); ?>

                                <br />
                                GST: <?php echo e($shipment->receiver->gst); ?>

                            </p>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col-8">
                            <table class="table-bordered table">
                                <thead>
                                    <th scope="col">SL No.</th>
                                    <th scope="col" style="width:20rem">Description</th>
                                    <th scope="col">Weight</th>
                                    <th scope="col">Serial No.</th>
                                    <th scope="col">Docket No.</th>
                                </thead>

                                <?php $__currentLoopData = $shipment->package; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr v-for="item in ">
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><?php echo e($item->description); ?></td>
                                    <td><?php echo e($item->weight); ?> kg</td>
                                    <td><?php echo e($item->serial_no); ?></td>
                                    <td><?php echo e($shipment->docket_no); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>

                            <table class="table-bordered table" style>
                                <tr>
                                    <th scope="row">Advance Paid</th>
                                    <td><?php echo e($shipment->charge_advance_paid); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">Balance Amount</th>
                                    <td><?php echo e($balance_amount); ?></td>
                                </tr>
                            </table>

                            <h6 class="mt-4">Remarks</h6>
                            <p><?php echo e($shipment->remarks); ?></p>
                        </div>
                        <div class="col">
                            <table class="table-bordered table">
                                <!-- <thead>
                          <th scope="col" colspan="4" class="text-center">Amount</th>
                        </thead>-->
                                <tr>
                                    <th scope="row">Transportation</th>
                                    <td><?php echo e($shipment->charge_transportation); ?></td>
                                </tr>

                                <tr>
                                    <th scope="row">Handling</th>
                                    <td><?php echo e($shipment->charge_handling); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">ODC Charges</th>
                                    <td><?php echo e($shipment->charge_odc); ?></td>
                                </tr>

                                <tr>
                                    <th scope="row">Halting</th>
                                    <td><?php echo e($shipment->charge_halting); ?></td>
                                </tr>

                                <tr>
                                    <th scope="row">Insurance</th>
                                    <td><?php echo e($shipment->charge_Insurance); ?></td>
                                </tr>
                                <tr>
                                    <th scope="row">GST</th>
                                    <td><?php echo e($shipment->charge_tax_amount); ?></td>
                                </tr>
                                <tr>
                                    <th>Total</th>
                                    <td><?php echo e($shipment->charge_total); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col">
                            <h6>Terms & Conditions</h6>
                            <ol>
                                <li>Remittance of payment within 7 days of invoice receipt.</li>
                                <li>A 10 % charge will be applied for every month of late payment.</li>
                                <li>GST Payable by Freight Bearer</li>
                            </ol>
                        </div>
                    </div>

                    <div class="row mt-2">
                        <div class="col">
                            <p>
                                Bank Details
                                <br />Name : Axis Bank
                                <br />8th Mile Branch
                                <br />A/c No.: 918020030455515
                                <br />IFSC: UTIB0002926
                                <br />
                            </p>
                        </div>
                        <div class="col-6"></div>
                        <div class="col">
                            <p>For and behalf of</p>
                            <img src="https://i.ibb.co/W6vkYqs/seal.png" alt="Rohith" class="img-fluid ml-3"
                                style="width:4rem;" />
                            <br />
                            <br />

                            <u>Gurukal Logistics</u>
                        </div>
                    </div>
                </div>

            </div>



        </div>



        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo e(asset('dashboard/vendor/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

        <!-- Core plugin JavaScript-->
        <script src="<?php echo e(asset('dashboard/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

        <!-- Custom scripts for all pages-->
        <script src="<?php echo e(asset('dashboard/js/sb-admin-2.min.js')); ?>"></script>

        <!-- Page level plugins -->


        <!-- Page level custom scripts -->


        <script src="<?php echo e(asset('js/app.js')); ?>"></script>

</body><?php /**PATH D:\coding\laravel\cargo\resources\views/invoice.blade.php ENDPATH**/ ?>