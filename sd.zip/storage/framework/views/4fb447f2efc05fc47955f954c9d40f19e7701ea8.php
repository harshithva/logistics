<?php $__env->startSection('content'); ?>

<div class="form-container">
    <div class="form-form">
        <div class="form-form-wrap">
            <div class="form-container">
                <div class="form-content" id="wrapper">
                    <h1 class="">Log In to <a href="<?php echo e(url('/')); ?>"><span class="brand-name">Gurukal</span></a></h1>
                    <p class="signup-link">New Here? <a href="<?php echo e(route('register')); ?>">Create an account</a></p>
                    <Login></Login>
                    <div class="container mt-4 text-center">
                        <a href="/track" class="btn btn-outline-primary mt-4 text-center">Track Shipment</a>
                    </div>

                    <p class="terms-conditions">© 2020 All Rights Reserved. <a href="<?php echo e(url('/')); ?>">Gurukal</a><br>
                        <a href="<?php echo e(url('https://vawebsites.in')); ?>" target="_blank">Powered by VAwebsites</a></p>

                </div>
            </div>
        </div>
    </div>
    <div class="form-image">

        <div class="l-image">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laravel\cargo\resources\views\auth\login.blade.php ENDPATH**/ ?>