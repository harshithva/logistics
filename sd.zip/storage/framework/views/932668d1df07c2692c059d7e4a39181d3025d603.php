

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('beautymail::templates.minty.contentStart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Gurukal Logistics</h1>
<br>
<h4>Customer Account has been created.</h4>
<p>You can login at: https://crm.gurukal.in</p>
<p>Your Email Address for login: <?php echo e($request->email); ?></p>
<p>Your Password: <?php echo e($request->password); ?></p>
<p>You can reset your password here: https://crm.gurukal.in/password/reset</p>
<br>
<p>Regards<br>Gurukal</p>
<p>Visit: <a>https://gurukal.in</a></p>


<?php echo $__env->make('beautymail::templates.minty.contentEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.ark', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laravel\cargo\resources\views/emails/customer/created.blade.php ENDPATH**/ ?>