

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('beautymail::templates.ark.heading', [
'heading' => 'Hello World!',
'level' => 'h1'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('beautymail::templates.ark.contentStart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h4 class="secondary"><strong>Hello World</strong></h4>
<p><?php echo e($data); ?></p>

<?php echo $__env->make('beautymail::templates.ark.contentEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('beautymail::templates.ark.heading', [
'heading' => 'Another headline',
'level' => 'h2'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('beautymail::templates.ark.contentStart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h4 class="secondary"><strong>Hello World again</strong></h4>
<p>This is another test</p>

<?php echo $__env->make('beautymail::templates.ark.contentEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.ark', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laravel\cargo\resources\views\emails\welcome.blade.php ENDPATH**/ ?>