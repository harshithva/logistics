

<?php $__env->startSection('content'); ?>


<?php echo $__env->make('beautymail::templates.widgets.articleStart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<p>Click on the link to view your quote.</p><br>
<a
    href="<?php echo e(ENV('APP_URL')); ?>/customer/quote/<?php echo e($quote->id); ?>/view"><?php echo e(ENV('APP_URL')); ?>/customer/quote/<?php echo e($quote->id); ?>/view</a>
<p>Regards<br>Gurukal</p>
<p>Visit: <a>https://gurukal.co.in</a></p>

<?php echo $__env->make('beautymail::templates.widgets.articleEnd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('beautymail::templates.ark', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\coding\laravel\cargo\resources\views\emails\quotes\quote.blade.php ENDPATH**/ ?>