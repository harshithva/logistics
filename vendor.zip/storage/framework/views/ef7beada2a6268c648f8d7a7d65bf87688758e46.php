<tr>
	<td class="w580" width="580" colspan="3">
		<img width="640" class="w640" id="toppbild" src="<?php echo e($src); ?>" alt="" height="<?php echo e($height); ?>" />
	</td>
</tr>
<tr>
	<td class="w640" height="10" width="640" colspan="3"></td>
</tr><?php /**PATH D:\coding\laravel\cargo\vendor\snowfire\beautymail\src\views\templates\ark\wideImage.blade.php ENDPATH**/ ?>