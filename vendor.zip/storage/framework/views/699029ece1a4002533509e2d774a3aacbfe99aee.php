<div class="block">
	<!-- Full + text -->
	<table width="100%" bgcolor="#f6f4f5" cellpadding="0" cellspacing="0" border="0" id="backgroundTable" st-sortable="fullimage">
		<tbody>
		<tr>
			<td>
				<table bgcolor="#ffffff" width="580" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidth" modulebg="edit">
					<tbody>
					<tr>
						<td width="100%" height="20"></td>
					</tr>
					<tr>
						<td>
							<table width="540" align="center" cellspacing="0" cellpadding="0" border="0" class="devicewidthinner">
								<tbody><?php /**PATH D:\coding\laravel\cargo\vendor\snowfire\beautymail\src\views\templates\minty\contentStart.blade.php ENDPATH**/ ?>